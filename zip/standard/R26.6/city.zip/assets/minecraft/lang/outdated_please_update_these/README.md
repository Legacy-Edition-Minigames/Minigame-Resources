# These translation files are outdated!!!

The translation changes in R26.2 require them to be updated for host config change messages to work!

Please consider updating them in a pull request! You can find all the changes you need to make [here.](https://github.com/DBTDerpbox/LEB-Resources/compare/R26.1...main#diff-c1c62792da0c52543190b3ab3aab843edda0d74101477dfcf6a431de59b04a4d)
